<?php

    //Verificar se os campos estão preenchidos
    if(empty($_POST["email"])){
        die("ERROR - Preencha o campo E-mail!");
    }

    if(empty($_POST["usuario"])){
        die("ERROR - Preencha o campo usuário!");
    }

    if(empty($_POST["senha"])){
        die("ERROR - Preencha o campo senha!");
    }

    $email = $_POST["email"];
    $usuario = $_POST["usuario"];
    $senha = $_POST["senha"];

    //Validar de acordo com o campo
    if(strlen($usuario) < 5 || strlen($usuario) > 10){
        die("ERROR - Usuario deve conter entre 5 e 10 caracteres.");
    }

    if(strlen($senha) < 4 || strlen($senha) > 20){
        die("ERROR - Senha deve conter entre 4 e 20 caracteres.");
    }

    //Verifica se o email, usuario e senha existem
    $e = "victor.lima@aedb.br";
    $u = "Victor";
    $s = "123456";

    if($email == $e && $usuario == $u && $senha == $s){
        echo("Logado com sucesso " .$usuario);
    }else{
        die("Login inválido.");
    }
?>