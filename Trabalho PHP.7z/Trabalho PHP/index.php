<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="style.css" rel="stylesheet">
    </head>
    <body>
    <div class="corpo-form" >
        <h1>LOGIN</h1>
        <form method="POST" action="validaformulario.php">
            <input type="email" name="email" placeholder="E-mail">
            <input type="text" name="usuario" placeholder="Usuário">
            <input type="password" name="senha" placeholder="Senha">
            <input type="submit" value="Login">
        </form>
    </div>
    </body>
</html>